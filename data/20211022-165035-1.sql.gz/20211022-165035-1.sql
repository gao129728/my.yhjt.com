-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : my_sanan-ic_com
-- 
-- Part : #1
-- Date : 2021-10-22 16:50:35
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `core_ad`
-- -----------------------------
DROP TABLE IF EXISTS `core_ad`;
CREATE TABLE `core_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `ad_position_id` int(10) DEFAULT NULL COMMENT '广告位',
  `url` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `closed` tinyint(1) DEFAULT '0',
  `orderby` int(11) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_ad`
-- -----------------------------
INSERT INTO `core_ad` VALUES ('71', '首页banner1', '1', '', '20211020/ca434a8ae5b080a5f92d535ac600730c.jpg', '1', '0', '10');
INSERT INTO `core_ad` VALUES ('72', '首页2', '1', '', '20211020/8ef9daf2b76ee7900ffe3d737c396d6c.jpg', '1', '0', '20');
INSERT INTO `core_ad` VALUES ('73', '首页3', '1', '', '20211020/afa9716521a2138105a57d364e29807a.jpg', '1', '0', '30');
INSERT INTO `core_ad` VALUES ('74', '内页banner1', '25', '', '20211020/ca434a8ae5b080a5f92d535ac600730c.jpg', '1', '0', '40');
INSERT INTO `core_ad` VALUES ('75', '内页2', '25', '', '20211020/ca434a8ae5b080a5f92d535ac600730c.jpg', '1', '0', '50');
INSERT INTO `core_ad` VALUES ('76', '内页3', '25', '', '20211020/ca434a8ae5b080a5f92d535ac600730c.jpg', '1', '0', '60');

-- -----------------------------
-- Table structure for `core_ad_position`
-- -----------------------------
DROP TABLE IF EXISTS `core_ad_position`;
CREATE TABLE `core_ad_position` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `orderby` int(11) DEFAULT '100' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_ad_position`
-- -----------------------------
INSERT INTO `core_ad_position` VALUES ('1', '首页轮播', '1', '1477140627', '1518228789', '1');
INSERT INTO `core_ad_position` VALUES ('25', '内页banner', '11', '1530499756', '1530499756', '1');
INSERT INTO `core_ad_position` VALUES ('26', '手机banner', '30', '1629185802', '1629185802', '1');
INSERT INTO `core_ad_position` VALUES ('27', '手机内页banner', '40', '1629186269', '1629186269', '1');

-- -----------------------------
-- Table structure for `core_add_field`
-- -----------------------------
DROP TABLE IF EXISTS `core_add_field`;
CREATE TABLE `core_add_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style` tinyint(11) DEFAULT '1',
  `value` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `core_add_field`
-- -----------------------------
INSERT INTO `core_add_field` VALUES ('1', '外链', '1', 'website');
INSERT INTO `core_add_field` VALUES ('17', '面积', '1', 'area');
INSERT INTO `core_add_field` VALUES ('19', '资金', '1', 'bankroll');

-- -----------------------------
-- Table structure for `core_admin`
-- -----------------------------
DROP TABLE IF EXISTS `core_admin`;
CREATE TABLE `core_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(32) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `core_admin`
-- -----------------------------
INSERT INTO `core_admin` VALUES ('1', 'admin', 'e73c461eb3da024a3389c0e65c5b3769', '20161122\\admin.jpg', '297', '127.0.0.1', '1550199922', 'admin', '1', '1', 'cfcd208495d565ef66e7dff9f98764da');
INSERT INTO `core_admin` VALUES ('9', 'xiaomei', '218dbb225911693af03a713581a7227f', '20161122\\ab9f9c492871857e1a6c5bc1c658ef7f.jpg', '20', '127.0.0.1', '1501321632', '田建龙', '1', '2', 'e96ed478dab8595a7dbda4cbcbee168f');

-- -----------------------------
-- Table structure for `core_article`
-- -----------------------------
DROP TABLE IF EXISTS `core_article`;
CREATE TABLE `core_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章逻辑ID',
  `sortnum` int(10) DEFAULT NULL,
  `title` varchar(128) NOT NULL COMMENT '文章标题',
  `admin_id` int(11) DEFAULT '0',
  `website` varchar(200) DEFAULT NULL,
  `cate_id` int(11) NOT NULL DEFAULT '1' COMMENT '文章类别',
  `photo` varchar(200) DEFAULT '' COMMENT '文章图片',
  `video` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `bigpic` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `annex` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(200) DEFAULT '' COMMENT '文章描述',
  `keyword` varchar(200) DEFAULT '' COMMENT '文章关键字',
  `description` text,
  `intro` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `content` text NOT NULL COMMENT '文章内容',
  `views` int(11) NOT NULL DEFAULT '1' COMMENT '浏览量',
  `attribute_ids` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `isTop` int(1) DEFAULT '0' COMMENT '是否推荐',
  `writer` varchar(200) DEFAULT NULL COMMENT '作者',
  `source` varchar(200) DEFAULT NULL,
  `ip` varchar(16) NOT NULL,
  `create_time` int(11) NOT NULL,
  `updata_time` int(11) DEFAULT NULL,
  `peoples` varchar(200) DEFAULT NULL,
  `cases` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `nums` varchar(200) DEFAULT NULL,
  `years` varchar(10) DEFAULT NULL,
  `postname` varchar(200) DEFAULT NULL,
  `department` varchar(200) DEFAULT NULL,
  `registered` varchar(200) DEFAULT NULL,
  `companies` varchar(200) DEFAULT NULL,
  `area` varchar(200) DEFAULT NULL,
  `bankroll` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `a_title` (`title`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=320 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `core_article`
-- -----------------------------
INSERT INTO `core_article` VALUES ('273', '10', 'Video_banner', '0', '', '48', '', '', '', '2021-10/163471451402590700.mp4', '', '', '', '', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634714454', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('274', '10', 'Pop_video', '0', '', '49', '', '', '', '2021-10/163471458212601200.mp4', '', '', '', '', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634714521', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('275', '10', 'About SAIC', '0', '', '41', '', '', '', '', '', '', '', '', '<p>Xiamen Sanan Integrated Circuit Co., Ltd. is located in the Torch (Xiang&#39;an) High-tech Development Zone of Xiamen City.The total planned land for the project is 281 mu, with a total investment of 3 billion yuan. This project is a major industrial project of Fujian Province 2014-2018 and a key project of Xiamen City in 2015. It is a strategic emerging industry supported by the state. ..</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634716227', '', '', '', '', '', '', '', '', '', '', '180000', '500');
INSERT INTO `core_article` VALUES ('276', '10', 'Company Profile', '0', '', '50', '', '', '', '', '', '', '', '', '<p>2222</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634720120', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('277', '10', 'Company Profile', '0', '', '56', '', '', '', '', '', '', '', '', '<p>Xiamen Sanan Integrated Circuit Co., Ltd. (&quot;SAIC&quot; for short) is located in the Xiamen Torch High-Tech Industrial Development Zone, with a total investment of 500M USD on a planned area of 180,000 square meters. It is one of the major industrial projects of the province of Fujian in 2014-2018 and and key projects of the city of Xiamen in 2015 in an emerging industry of strategic importance with government support.\nSAIC established a compound semiconductor manufacturing platform which combines process technologies for microwave radio frequency, high power electronics, and optical, by having in-house capability and vertical integration of substrate materials, epitaxy growth and wafer fabrication. SAIC owns large scale of MOCVD epitaxy growth production lines and the most advanced process technologies.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634799926', '', '', '', '', '', '', '', '', '', '', '180000', '500');
INSERT INTO `core_article` VALUES ('278', '20', 'Manufacturing', '0', '', '56', '20211021/8b8de70aa77a1c6d64920ab7495a10f5.jpg', '', '', '', '', '', '', '', '<p>SAIC is proud of highly reliable processes and extensive experience in wafer foundry, with professional R&amp;D teams, both at home and abroad. SAIC offers the most competitive products with optimal manufacturing efficiency, focused on the development of high-end technologies for microwave radio frequency, power electronics and optical devices, and strives for developing leading processes and for constant improvements in process capabilities.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634801170', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('279', '30', 'Microwave Radio Frequency', '0', '', '56', '20211021/7763d87546ca35f26bbbff714acd6db6.jpg', '', '', '', '', '', '', '', '<p>In the field of radio frequency\nmillimeter wave, SAIC has launched advanced process\ntechnologies for wireless applications such as GaAs HBT,\npHEMT, and GaN HEMT, and has built a large-scale\nprofessional 4-inch and 6-inch compound wafer manufacturing\nline.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634802028', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('280', '40', 'Power Electronics', '0', '', '56', '20211021/fc7efd4132d8853b24b46f2dd285db33.jpg', '', '', '', '', '', '', '', '<p>In the field of power electronics,SAIC has launched SiC power diodes and silicon-based GaN power devices with high reliability and high power density.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634802213', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('281', '50', 'Optical Communication', '0', '', '56', '20211021/fbf433ed5977560c066825493e400cdc.png', '', '', '', '', '', '', '', '<p>In the field of optical communications, SAIC has been capable of producing DFB lasers, photodiodes, avalanchphotodiodes and other high-speed optical communication products, and has developed high-power visible and infrared VCSELs, edge-emitting lasers\nand other products including for 3D sensing, LiDar and other\n consumer applications.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634802315', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('282', '10', 'SAIC，', '0', '', '51', '20211021/5ebc44c2f46e03955d9d53d6403a5949.jpg', '', '', '', '', '', '', '<p>Dedicated to Drive Compound Semiconductor Innovation.</p>', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634804546', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('283', '20', 'TO BECOME', '0', '', '51', '', '', '', '', '', '', '', '', '<p>The world-class compound semiconductor R&amp;D, manufacturing and service provider</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634804665', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('284', '30', 'TO SERVICE', '0', '', '51', '', '', '', '', '', '', '', '', '<p>Fabless and IDM’s companies, and in partnership with them, to become a competitive force in semiconductor industry.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634804708', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('285', '40', 'Method', '0', '', '51', '', '', '', '', '', '', '', '<p>International Level Systemized Process</p>', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634805894', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('286', '50', 'Production Capacity', '0', '', '51', '', '', '', '', '', '', '', '<p>On Time Delivery Quality Assurance</p>', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634805918', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('287', '60', 'Culture', '0', '', '51', '', '', '', '', '', '', '', '<p>Customer-Centric, Intellectual Property Protection</p>', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634805932', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('288', '70', 'Technology', '0', '', '51', '', '', '', '', '', '', '', '<p>Continuous R&amp;D Support Design Support</p>', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634805958', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('289', '10', 'Milestone', '0', '', '52', '20211021/e262e69e64e6105914cc6fd733bb732a.jpg', '', '', '', '', '', '', '<div class=\"ins_tab_fa\"><div class=\"ins_tab_btn\"><div class=\"time_year\">2019</div></div><div class=\"ins_tab_btn\"><div class=\"time_year\">2018</div></div><div class=\"ins_tab_btn\"><div class=\"time_year\">2017</div></div><div class=\"ins_tab_btn\"><div class=\"time_year\">2016</div></div><div class=\"ins_tab_btn\"><div class=\"time_year\">2015</div></div><div class=\"ins_tab_btn\"><div class=\"time_year\">2014</div></div></div>', '<div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2019</div><div class=\"waterfull clearfloat\"><ul class=\"grid0 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>05</div><div class=\"pure fin_con_box\"><div class=\"at_on\">SA8000/ISO26000 Certified</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>07</div><div class=\"pure fin_con_box\"><div class=\"at_on\">VCSEL product Mass Production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>08</div><div class=\"pure fin_con_box\"><div class=\"at_on\">5G Base Station PA Pilot Production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>11</div><div class=\"pure fin_con_box\"><div class=\"at_on\">ISO22301 Certified</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>12</div><div class=\"pure fin_con_box\"><div class=\"at_on\">IATF16949 Certified</div></div></div></li></ul></div></div><div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2018</div><div class=\"waterfull clearfloat\"><ul class=\"grid1 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>01</div><div class=\"pure fin_con_box\"><div class=\"at_on\">850nm 25G PD mass production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>05</div><div class=\"pure fin_con_box\"><div class=\"at_on\">ISO27001 certificated</div><div class=\"at_on\">0.15µm pHEMT LNA mass production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>09</div><div class=\"pure fin_con_box\"><div class=\"at_on\">650V,1200V SiC Power SBD mass production</div><div class=\"at_on\">P15 LN pHEMT mass production</div></div></div></li></ul></div></div><div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2017</div><div class=\"waterfull clearfloat\"><ul class=\"grid2 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>01</div><div class=\"pure fin_con_box\"><div class=\"at_on\">QC080000 certified</div><div class=\"at_on\">HBT HG Process Released for 4G High Band Production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>08</div><div class=\"pure fin_con_box\"><div class=\"at_on\">WiFi 802.11ac PA mass production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>12</div><div class=\"pure fin_con_box\"><div class=\"at_on\">Mass production of 1310nm/1550nm 25G&nbsp; PD</div><div class=\"at_on\"></div></div></div></li></ul></div></div><div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2016</div><div class=\"waterfull clearfloat\"><ul class=\"grid3 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>04</div><div class=\"pure fin_con_box\"><div class=\"at_on\">HBT HL Process Released for 3G Product Mass Production</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>05</div><div class=\"pure fin_con_box\"><div class=\"at_on\">ISO9001 certificated</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>12</div><div class=\"pure fin_con_box\"><div class=\"at_on\">HBT HR Process Released for 2G Product Mass Production</div></div></div></li></ul></div></div><div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2015</div><div class=\"waterfull clearfloat\"><ul class=\"grid4 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>06</div><div class=\"pure fin_con_box\"><div class=\"at_on\">CICIIF invested Sanan</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>07</div><div class=\"pure fin_con_box\"><div class=\"at_on\">4K/M 6inch capacity installed</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>08</div><div class=\"pure fin_con_box\"><div class=\"at_on\">First MPW tape out</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>11</div><div class=\"pure fin_con_box\"><div class=\"at_on\">First Sample delivered to customers.</div></div></div></li></ul></div></div><div class=\"scroll-animate father mil_con_text_box pure\"><div class=\"minl_year_m\">2014</div><div class=\"waterfull clearfloat\"><ul class=\"grid5 content list-paddingleft-2\"><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>05</div><div class=\"pure fin_con_box\"><div class=\"at_on\">Company founded</div></div></div></li><li class=\"item1\"><div class=\"at_on\"><div class=\"fin_time_box at_on\"><div class=\"at_on\">Month</div>08</div><div class=\"pure fin_con_box\"><div class=\"at_on\">Infrastructure construction</div></div></div></li></ul></div></div>', '0', '', '1', '0', '', '', '127.0.0.1', '1634806226', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('290', '10', 'content&photo', '0', '', '53', '20211022/4b6967d36d5b5958e0bf94db9181a3f0.jpg', '', '', '', '', '', '', '', '<p>With abundant wafer foundry resources and advanced manufacturing technology, Sanan-IC can meet the customers&#39; requirements on RF wireless communication and millimeter wave. Sanan-IC provided OEM services include complete foundry process, including Design support, Device model guide book, process Design suite (PDK),computer aided Design (CAD) and other parameter databases, so as to provide customers with a convenient Design environment. In addition, Sanan-IC provides complete product testing service, and work with customers to accelerate product development.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634864847', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('297', '10', 'content&photo', '0', '', '54', '20211022/7d4907b78155b7f04d2a4a9c2ad38d91.jpg', '', '', '', '', '', '', '', '<p>The advance of an energy-efficient world lies in the next generation power conversion technique using wide bandgap (WBG) power devices (e.g., silicon-carbide (SiC ) or gallium-nitride (GaN) based). Compared with conventional Si based devices, these devices can operate at higher voltage and temperature. Also, they can switch at faster speeds with lower switching losses. This allows for greater power efficiency, smaller size, lighter weight, lower overall cost of power systems. Currently, the evolutionary WBG solutions are taking hold in various application field: Power adapters for consumer electronics, Data centers, Electric Vehicles (EV), Industrial motors, wireless charging, and energy harvesting.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634868385', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('300', '10', 'content&photo', '0', '', '55', '20211022/792c63dd4ab258388d9dc2101e9f03a0.jpg', '', '', '', '', '', '', '', '<p>SAIC provides world class wafer foundry services for III-V compound semiconductors and offers high quality processes with exceptional service. In the fields of optical communications and photonics, SAIC offers wafer fabrication for customized singulated VCSELs and arrays, DFB lasers, photodiodes, avalanche photodiodes (APDs), monitor photodiodes (MPDs), and other high-speed optical products. Capabilities include high-power visible and infrared VCSELs, edge-emitting lasers for 3D sensing, LiDar and several consumer applications.</p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634869713', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('319', '10', 'GaAs', '0', '', '57', '', '', '', '', '', '', '', '', '', '2', '', '1', '0', '', '', '127.0.0.1', '1634888821', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('303', '10', 'Policy', '0', '', '63', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">三安集成电路是中国具备规模化研发、生产化合物半导体芯片能力的公司，秉持全方位安全、卫生、环保管理之经营理念，向员工提供并持续改善安全与健康的工作环境，视保护环境、绿色生产、预防职业伤害与疾病、善尽企业社会责任为公司经营管理之重要环节。希望藉由环安卫管理系统之贯彻实施，持续保持与员工、顾客、承揽商、供货商、社会大众等利害相关者之沟通管道，达成企业永续经营之最终目的。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">公司在环境方面的承诺：<br/>1、遵守适用的国家和地方现行有关环境法律、法规。<br/>2、从材料、设备、物资的采购，产品生产、服务全过程实行污染预防，预防和减少各<br/>种污染物的产生和排放。<br/>3、加强污染防治，完善环境设施，努力实现污染物处理全面达标，排量递减。<br/>4、提高全员环境意识，关爱环境，着力宣传环境方针、环境目标，强化全员环境行为。<br/>5、不断改进工艺，改进设备，节约资源、能源，推进清洁生产，开展三废综合利用，<br/>持续改进环境管理。 6、定期对公司环境绩效进行评价，使公司环境管理得到持续改进。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634873819687217.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 156px; height: 143px;\" _src=\"/ueditor/php/upload/image/20211022/1634873819687217.jpg\"/>&nbsp;<img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634873820897384.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 153px; height: 139px;\" _src=\"/ueditor/php/upload/image/20211022/1634873820897384.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">公司在职业健康安全方面的承诺：<br/>以人为本是企业持续发展的核心，从员工的需求和安全出发，为员工创造一个安全舒适 的工作环境，建立安全操作方法，保证有效的安全培训，制定安全责任制，引导员工关 心安全，才能发挥最大的生产效能。<br/>严格遵守国家关于职业健康安全方面的法律、法规、安全管理标准和技术规范，履行向国家主管部门和社会的承诺；通过管理水平的提升，提高员工的安全生产意识，规范企业的行为，实现职业健康安全绩效的持续改进，为企业的永续发展保驾护航。</p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634873712', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('304', '20', 'MANAGEMENT SYSTEM', '0', '', '63', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12pt;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: 宋体;\">为善尽企业社会责任，我司于2014年成立后，致力于环境保护、员工安全及健康促进的提升；于2020年7月通过了必维认证公司之ISO 14001及ISO 45001认证，并将此两套体系合并为公司内部之环安卫管理系统，以推动公司内部环境管理及职业安全卫生相关管理活动。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634873848117691.png\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 501px; height: 465px;\" _src=\"/ueditor/php/upload/image/20211022/1634873848117691.png\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12pt;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: 宋体;\">公司的环安卫管理系统运作，依循总经理颁布之环安卫政策，依据最新组织架构规划环安卫管理工作，其中由副总经理担任环安卫管理代表，负责审核及推动环安卫管理运作事项；根据环安卫方针政策，环安部依各部门风险评估结果研拟具体可行之工作目标并督促各部门执行，再定期进行进度追踪；通过内部环安卫稽核，对整体系统运作执行状况进行检查与纠正，并将稽核结果及系统执行成效提报环安卫管理代表及安全委员会进行审查，共同检讨及修正，以达到持续改善之目的。</span></span></p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634873837', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('305', '10', '环保工作情况公开报告', '0', '', '64', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">一、企业基础信息</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ● 单位名称：厦门市三安集成电路有限公司</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;<span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">统一社会信用代码：913502003028266333</span></span></span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">法定代表人：林科闯</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">生产地址：福建省厦门市同安区洪塘镇民安大道753-799号</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">环保联系方式： 0592-6300385/林先生</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">项目规模：项目总建筑面积为237446.85m2，总投资300475万元，预计项目</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年产</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">GaAs</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">高速半导体外延片21万片、SiC外延片3.6万片、光通讯外延片9.48万片、GaAs高速半导体芯片21万片、GaN高功率半导体芯片6万片、SiC芯片6万片、光通讯芯片1.5302万片、SOP封装48470万颗、封装测试6030万颗、光通讯封装测试100万颗、外延片快测90片/a</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">。</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;margin-left: 52px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;text-indent: 0;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">二、建设项目环境影响评价及其他环境保护行政许可情况</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">2015</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年6月24日取得一期项目环境影响评价报告的批复；2016年11月2日通过一阶段环保验收；2018年8月22日通过二阶段环保验收。</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp; ●&nbsp;</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">2019</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年8月28日取得光互联用25Gb/s光收发芯片与器件生产线项目暨一期改建项目环境影响评价报告的批复。</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\">2020</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\">2</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">月</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\">27</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">通过环保验收。</span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 1\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">&nbsp;●</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">国家版排污许可证：于2020年8月23日取得，证书编号：913502003028266333001Q</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;margin-left: 52px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;text-indent: 0;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 20px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">三、企业治污减排设施情况</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 19px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: bold\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: normal\">在公司建设过程中，公司内部环保工作也跟随国家环保政策的步伐进行相应的改进，建设了污水站、废气处理设施等污染物处理设施，积极履行了企业的环保责任。由公司总经理牵头，环安部负责具体推进环境管理体系的日常运行工作，水气化处理部及空调电力部负责环境保护设施的日常运行、测试记录、保养维护、及配合环保部门参与企业环保设施的竣工验收、监督监测工作等。</span></span></span></span></span></span></span></span></span></p><ol style=\"padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\" class=\" list-paddingleft-2\"><li style=\"\"><p><span style=\";padding: 0px;border: none;box-sizing: border-box;position: relative;z-index: 1;font-size: 19px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: bold\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: normal\">污水治理情况</span></span></span></span></span></span></span></span></span></p></li></ol><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">我司产生的废水，主要包括酸碱废水、有机废水、含氟废水、低浓度含氨废水、含砷废水及生活污水，主要排放的水污染物包括氟化物、总砷、pH、COD、BOD5、氨氮、总磷、悬浮物等。为确保废水达标排放，我司斥资1200 万元，主要建设了含砷废水处理设施、含氟废水处理设施、含氨废水处理设施、有机废水处理设施、酸碱废水处理设施、生活污水预处理设施、雨水综合管网、污水综合管网、排污口规范化建设等。含砷废水采用袋滤+氢氧化钠-氯化铁混凝沉淀法处理+UF 超滤处理+离子交换处理；含氟废水经除氟系统（钙盐沉淀-絮凝沉淀法）处理后进入含氨废水调节槽，与含氨废水共同处理；有机废水经过有机废水处理系统处理后与含氨废水调节槽出水一并进入生化系统处理；酸碱废水经过酸碱调节池调节处理；生活污水经化粪池处理。含砷剩余污泥和含氟剩余污泥脱水分别采用了1 台板框式污泥压滤机，有机剩余污泥脱水采用了一台离心式脱水机。达标排放废水通过市政污水管网排入翔安污水处理厂集中处理。</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">近一年来，我司污水站整体运行情况良好，根据我司水污染源自动监控设备数据显示，污水主要污染物COD、氨氮、As等排放浓度数据无超标情况，且都远低于污染物浓度限值。我司执行的水污染物排放标准如下：总砷（0.2mg/L）、COD（500mg/L)、BOD5(300mg/L) 、氨氮(45mg/L)、SS(400mg/L)、总磷(8mg/L)、氟化物(20mg/L)、总铜（2mg/L）</span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">。</span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\">2020<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年</span>8<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">月委托厦门中讯德检测有限公司对我司废水污染物进行检测，检测结果为总砷（</span>0.031mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、</span>COD<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">（</span>20mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、</span>BOD5<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">（</span>7mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、氨氮（</span>17.5mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、总磷（</span>0.99 mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、</span>SS<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">（</span>30mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、氟化物（</span>5.05mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、总铜（</span>0 mg/L<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）。</span>2020<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年我司主要污染物排放量为</span>COD&nbsp;<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">（</span>4.049 T<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、氨氮（</span>0.055 T<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、总砷（</span>0.006 kg<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">），污染物排放浓度及总排放量均符合要求。</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;margin-left: 24px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;text-indent: 0;white-space: normal;background-color: rgb(255, 255, 255)\">&nbsp;</p><ol style=\"padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\" class=\" list-paddingleft-2\"><li style=\"\"><p><span style=\";padding: 0px;border: none;box-sizing: border-box;position: relative;z-index: 1;font-size: 19px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: bold\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: normal\">废气治理情况</span></span></span></span></span></span></span></span></span></p></li></ol><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">本项目芯片生产过程中，酸清洗、湿法蚀刻、干法蚀刻工序产生的酸性废气，主要含Cl2、氟化物、氯化氢，经2 套玻璃钢喷淋塔处理，NaOH 碱液喷淋，设计净化率为90%以上，处理达标后经1 根29m 高排气筒排放。芯片生产的碱洗、光刻、湿法刻蚀等工序产生碱性废气，主要含NH3，采用2 套玻璃钢喷淋塔处理，HCl 溶液喷淋，设计净化率为93～95%，处理达标后经1 根23m 高排气筒排放；芯片生产的有机清洗、光刻、去光阻等工序产生的有机废气，主要含丙酮、TVOC，采用1 套沸石转轮+蓄热式焚化炉处理，沸石转轮将有机废气中的有机物吸附后（设计净化率95%以上），再脱附到蓄热式焚化炉焚烧处</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">理，焚烧烟气与经沸石转轮净化后的废气通过1 根21m 高排气筒排放。车间内通风置换的一般废气，主要为空气，通过1 根20m 高排气筒直接排放。废水处理站酸碱废气采用1 套“酸碱双塔玻璃钢净化塔”处理后通过28m 高排气筒排放。食堂油烟废气经一台油烟净化器处理后通过17m 高排气筒排放。为确保废气达标排放，我司共斥资264.56 万元，主要建设了碱性废气处理设施、酸性废气处理设施、有机废气处理设施、废水站废气处理设施等各种废气收集装置等。</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">我司执行的大气污染物排放标准如下：氟化物（5mg/ m³）、氯气（25mg/ m³）、硅烷（5mg/ m³）、氯化氢（30mg/ m³)、氨气（1.5mg/ m³）、非甲烷总烃（60mg/m³）、颗粒物（30mg/m³）、二氧化硫（220mg/m³）、氮氧化物（200mg/m³）等</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">。</span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\">2020<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年</span>12<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">月委托委托厦门中讯德检测有限公司对我司废气污染物进行检测，检测结果为</span></span></span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">氟化物（</span>1.28 mg/ m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³）、氯气（</span>3.1 mg/ m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³）、氯化氢（</span>1.9 mg/ m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³）、氨气（</span>0.07 mg/ m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³）、非甲烷总烃（</span>4.58 mg/m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³）、颗粒物（未检出）、二氧化硫（未检出）、氮氧化物（</span>7.1 mg/m<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">³），</span><strong style=\";padding: 0px\">2</strong>020<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年我司主要污染物排放量为：氮氧化物（</span>0.158 T<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）、二氧化硫（</span>0.017 T<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">）。污染物排放浓度及总排放量均符合要求。</span></span></span></span></p><ol style=\"padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\" class=\" list-paddingleft-2\"><li style=\"\"><p><span style=\";padding: 0px;border: none;box-sizing: border-box;position: relative;z-index: 1;font-size: 19px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: bold\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: normal\">厂界噪声控制</span></span></span></span></span></span></span></span></span></p></li></ol><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">我司对厂内重要噪声源的治理，以减少噪声源，阻隔传播途径和对受害者进行保护三方面相结合，具体采用了合理布置噪声源，使其远离敏感点，噪声设备安装消声器、减震地垫、螺栓及消声百叶等减震设施，并于厂界种植绿化隔声屏障，确保厂界噪声达标。</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px;text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">项目西北侧厂界噪声执行《工业企业厂界环境噪声排放标准》（GB12348-2008）3类标准，东南侧侧厂界噪声执行《工业企业厂界环境噪声排放标准》（GB12348-2008）4类标准，详见下表。</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">表4 &nbsp;GB12348-2008《工业企业厂界环境噪声排放标准》&nbsp; 单位：dB（A）</span></span></span></span></span></p><table width=\"1009\" style=\"width: 925px;\"><tbody style=\";padding: 0px;border: none;box-sizing: border-box\"><tr style=\";padding: 0px;border: none;box-sizing: border-box;height: 23px\" class=\"firstRow\"><td width=\"336\" style=\"border-top-width: 2px; border-top-color: windowtext; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">类别</span></span></span></p></td><td width=\"336\" style=\"border-top-width: 2px; border-top-color: windowtext; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">昼间</span></span></span></p></td><td width=\"336\" style=\"border-top-width: 2px; border-top-color: windowtext; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">夜间</span></span></span></p></td></tr><tr style=\";padding: 0px;border: none;box-sizing: border-box;height: 23px\"><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">3</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">类</span></span></span></p></td><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">65</span></span></span></p></td><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">55</span></span></span></p></td></tr><tr style=\";padding: 0px;border: none;box-sizing: border-box;height: 23px\"><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">4</span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">类</span></span></span></p></td><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">70</span></span></span></p></td><td width=\"336\" style=\"border-top: none; border-left: none; box-sizing: border-box; border-bottom: 1px solid rgb(102, 102, 102); border-right: 1px solid rgb(102, 102, 102); padding: 5px;\"><p style=\";border: none;box-sizing: border-box;text-align: center\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">55</span></span></span></p></td></tr></tbody></table><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\">2020<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">年委托中委托厦门中讯德检测有限公司对我司厂界噪声污染物进行检测，检测结果为：东侧昼间</span>[60 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、东侧夜间</span>[52 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、南侧昼间</span>[59 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、南侧夜间</span>[49 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、西侧昼间</span>[61 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、西侧夜间</span>[50 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、北侧昼间</span>[61 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">、北侧夜间</span>[52 dB(A)]<span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">，厂界噪声全部达标。</span></span></span></p><ol style=\"padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\" class=\" list-paddingleft-2\"><li style=\"\"><p><span style=\";padding: 0px;border: none;box-sizing: border-box;position: relative;z-index: 1;font-size: 19px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 28px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: bold\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-weight: normal\">固废治理</span></span></span></span></span></span></span></span></span></p></li></ol><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">我司生产中产生的所有固废分类收集，临时堆场按照《一般工业固体废物贮存、处置场污染控制标准》（GB18599-2001）建设控制，生活垃圾交由城市垃圾处理厂做填埋处置，可回收固废签订了有相关加工、处置的公司进行回收利用。危险废弃物签订了有危险废弃物出资的公司进行处置，严格执行危废处理流程及五联单制度，完全做到合法、合规性处置。</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">四、环保机构设置及环境管理制度的建立情况</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\">&nbsp;</span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">为了做好安全环保工作，公司成立了以总经理为第一责任人的安全环保管理小组，并专门设置了环安部，设立环保工程师岗位，负责日常环境保护和环境污染防治设施的监督考核工作。各部门、各班组设置了兼职安全环保管理员，负责本部门的安全环保管理工作。</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 21px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">根据管理需要，制定并发布了《环保管理制度》、《大气污染防治管理程序》、《水污染防治管理程序》、《噪声污染防治管理程序》、《一般工业固废污染防治管理程序》、《环保设施管理程序》、《土建活动污染防治管理程序》、《建设项目环境保护管理程序》、《突发环境事件应急预案》、《危险废弃物清理作业规范》、《供应商管理作业规范》、《意外事故通报、调查与处理程序》、《环安监督与量测作业程序》、《环安紧急应变作业程序》等一系列环境保护管理制度。</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 14px\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 24px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">五、环保工作目标</span></span></span></span><br/>&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">在全国提倡环保的当下，公司领导认识到企业自身的环保责任重大，多次强调落实多项环保工作，将严格执行国家相关的法律、法规及厦门市环保局环评批复上的各项规定，树立我司“遵守法规、预防污染；关爱环境、全员参与；优化工艺、节能降耗；定期审查、持续改进”的环境方针，发展循环经济，实现清洁生产，继续做好环保减排工作，为环保事业做出贡献。</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: right\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">厦门市三安集成电路有限公司</span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: right\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 宋体\">2021/04/12</span></span></span></p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879167', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('306', '20', '环境风险防范工作开展情况说明', '0', '', '64', '', '', '', '', '', '', '', '', '<h5 style=\"margin: 32px 0px 12px; padding: 0px 0px 0.546875rem; border: none; box-sizing: border-box; font-variant-ligatures: common-ligatures; overflow-wrap: break-word; line-height: 1.5; font-size: 14px; text-align: center; float: none; width: 1009px; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">环境风险防范工作开展情况说明</h5><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">厦门市三安集成电路有限公司（以下简称我司），于2014年4月11日正式签约落户厦门火炬高新区，项目位于同安区，东临滨海大道，南临民安大道，西临同龙三路，总用地面积187754.40平方米（约281亩），属于国家扶持的战略性新兴产业，被列入福建省重大工业项目和厦门市重点工业项目。项目总投资30亿元，预计年产GaAs高速半导体外延片21万片、SiC外延片3.6万片、光通讯外延片9.48万片、GaAs高速半导体芯片21万片、GaN高功率半导体芯片6万片、SiC芯片6万片、光通讯芯片1.5302万片、SOP封装48470万颗、封装测试6030万颗、光通讯封装测试100万颗、外延片快测90片/a。我司于2020年8月23日取得国家排污许可证。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">一、企业突发环境事件应急管理情况：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">1、为积极应对各种突发环境事件，有序、高效地组织指挥事故抢险救援工作，我司于2020年1月20日发布《突发环境事件应急预案》并实施，并在同安环保分局进行备案，备案编号为350212-2020-002-M；预案附件中包含了突发环境事件风险评估，确定我司风险等级为较大环境风险。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">2、我司已建制专门的环境事件隐患排查治理制度，并按照制度定期对进行厂区环境安全隐患排查。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">3、我司具有完善的紧急应变体系，并按规定配备充足的紧急应变器材及相关物资，设置环安部并配备专职环安人员进行厂区环保及安全的监督管理；厂区配有中央控制室，通过摄像头监控、毒害性气体探测器及在线监测仪对厂区运行情况进行24小时监控；并将中央控制室设置为应急救援办公室，负责应急救援的日常管理；工作现场配置自给式空气呼吸器（SCBA）、丘比特电动送风防护套组、长管式空气呼吸器、泄漏处理车、四用气体侦测器、防爆抽风机、救援三脚架、防护服等大量紧急应变器材；成立紧急应变小组，为使ERT成员熟练使用紧急应变器材，环安专业人员对ERT进行专项培训及考核，确保发生紧急情况时可在第一时间有效处理。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">4、为检验企业突发环境事件应急水平，完善突发环境事件应急预案，我司每年定期开展公司特殊气体泄漏应急演练，并与同安区环保局开展化学品泄漏联合演练，希望籍演练锻炼企业及时妥善处理突发事件的能力，把突发环境事件消除在萌芽状态，避免给企业人员和周边居民带来损害，造成环境污染。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">二、企业突发环境事件风险防控措施布设情况：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">1、项目按照环评批复及应急预案要求，配备充分的防止泄露紧急应变物资；根据环评报告要求对地下水污染采取分区防治，对重点污染防治区、一般污染防治区不同防渗等级要求，采取了地面防渗及管道防渗措施，避免污染地下水；于2015年完成地下水监控井的建制，并采用半年一次的频率进行监测；若污染事故发生或发现监控井地下水受到污染时，即启动公司紧急应变方案，及时报告项目环境管理机构负责人，并采取必要的应急处置措施及防治措施。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">2、废水处理站1F配置总容量641m3的应急池收纳事故废水，应急池设置地点为地上，故一般采用水泵等提升装置将受污染的废水打入处理；一旦遭遇停电，动力站1F配置有紧急发电机系统，并接入事故应急设施动力装置，确保污水收纳。项目放流口切断闸门采用电动、手动两式并有专人负责，紧急情况下关闭废水站放流池排水提升泵即可切断。雨水放流井则加设紧急回抽装置，以确保事故初期雨水可回收到废水站相应事故应急池；重点污染防治区域均设置导流沟及集水坑，如危废仓，废水站，化学品仓库等区域。危废仓集水坑容积约为8立方米，废水站集水坑容积约为6立方米，化学品仓库集水坑容积约为3立方米。集水坑均设置抽水泵浦，一旦发生泄漏，抽水泵浦及相应管道即可将泄漏物收集到废水站及储液池进行处理达标后排放。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">三、突发大气环境事件风险防控措施布设情况：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">1、因生产需求，我司有使用有毒有害气体（NH3­、CL2、BCl3、SiH4、AsH3、PH3等）。特气在未使用之前，气体的出口处用铅封密封，保证气体不泄漏。特气的摆放严格按照其理化性质分类存放，确保气瓶的瓶帽、阀门、内锁、铅封四道保险正常有效。气体储存间外围安装标有明显的剧毒、防火警告标志，存放在专用而牢固的地方并锁好，存放场所远离居民区并封闭，无关人员无法进入。对剧毒物品存放场所以白底红字“剧毒物”表示，配备具有专业资质的人员进行全天不间断值班巡检，剧毒气体储存间实行双人收发、双人保管制度，管理人员必须持证上岗。在生产车间内部设置了各类气体监控装置，与气柜联动。车间内任何气体超标，与主设备配套的监测器将自动报警并切断气源。在尾气处理系统上、尾气的最终排放口上也都安装了有毒气体监测器，一旦排放尾气超标，监测器将进行声光报警并切断所有气源，人员将立即疏散。同时还配备相应便携式气体侦测器，在气瓶的转移、更换等过程中进行实时监控，如果有害气体泄漏，须有身着全面罩呼吸器、全身防护服的操作人员及时应对，排除故障，避免任何事故发生，以保证员工的人身安全和环境空气不受到污染。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;&nbsp; 2、一旦发生可能污染周边单位及居民的特气泄漏，我司立即按照突发环境事件应急预案，立即采取防治措施，及时通报周边可能受污染危害的单位和居民，并通报环保分局。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">我司现已满足环境安全生产条件，并已向环保局进行报备，确保安全生产。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: right;\">厦门市三安集成电路有限公司</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: right;\">2021/4/12</p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879190', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('307', '10', '危险废物泄漏联合演练公告', '0', '', '65', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">为检验企业突发环境事件应急水平，同安区环保局经过多家公司评比，最终认为我司应急装备充足，ERT组织完善，具备较高的紧急应变水平，遂决定与我司开展突发环境事件紧急应变联合演练，并希望籍此次演练，锻炼企业及时妥善处理突发事件的能力，把突发环境事件消除在萌芽状态，避免给企业人员和周边居民带来损害，造成环境污染。<br/>从确定联合演练开始，我司即积极开展准备工作，跟分局人员密切联系沟通演练事宜，布置现场、准备物资，为达到预期演练效果，在环安同仁的组织及各位领导、同仁的支持下，多次在厂内预演，一切都有条不紊地进行。<br/>【演习时间】：2016/11/23 16:00~16:30<br/>【演习内容】：IPA泄漏+企业自救+环保分局营救<br/>【演习花絮】：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180012.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 660px; height: 311px;\"/><br/><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180506.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 673px; height: 615px;\"/><br/><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180534.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 663px; height: 593px;\"/><br/><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180555.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 667px; height: 624px;\"/><br/><br/><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180800.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 665px; height: 587px;\"/><br/><br/>&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">【亮点展示】：<br/>本次演习获得同安区政府大力支持，并派同安区政府宣传部在演习期间来到联合演习现场进行观摩，整个演习过程我司表现不负众望，流程紧凑，分工协作应变熟练，获得一致好评。针对此次演习，区政府宣传部还在同安政府网站上专门发布了新闻稿，并称我司突发环境事件应急水平全省领先。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><br/><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180813.png\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 555px; height: 419px;\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">新闻稿链接：<br/>http://www.xmta.gov.cn/zwxx/tayw/201611/t20161124_314013.htm<br/><br/>此次联合演练至此圆满结束，环安在此感谢各部门领导的大力支持！感谢所有参演同仁协助配合！</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><br/><img alt=\"\" src=\"http://www.sanan-ic.com/upfiles/images/20190218180833.png\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 642px; height: 351px;\"/></p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879275', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('308', '20', '特气房氨气泄漏演习总结公告', '0', '', '65', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">为评估公司特气房应急管理体系是否完善、处置程序是否科学、职责是否清晰，进一步完善部门之间的协调机制，提升员工自我保护及应急救援能力，提升公司对特气房故障的应急处置水平，环安撰写演习方案和演习剧本，组织开展了此次特气房氨气泄漏演习。 为使演习方案能够更真实体现灾情状况，环安多次与厂务特气系统主办讨论应变内容，确认演习方案，力争方案真实、有效。为使同仁理解演习进程和演习目的，环安召开演习说明会、并组织厂务ERT成员进行培训。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\">&nbsp;<img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634879303435696.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 472px; height: 172px;\" _src=\"/ueditor/php/upload/image/20211022/1634879303435696.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">本次演习流程如下：</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); text-align: center;\"><br/><br/><img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634879304812181.jpg\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; width: 687px; height: 463px;\" _src=\"/ueditor/php/upload/image/20211022/1634879304812181.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; border: none; box-sizing: border-box; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">希望藉此次演练，公司同仁能够更好的理解紧急应变模式，熟悉应变器材的穿戴和使用，使用适当的沟通工具，提高自我保护及应急救援能力，提升特气房故障的应急处置水平，确保安全生产。</p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879302', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('309', '10', 'NO CONFLICT MINERALS COMMITMENT', '0', '', '62', '', '', '', '', '', '', '', '', '<p><span style=\"font-family: Arial, sans-serif; font-size: 14px; letter-spacing: 1px; text-align: justify; white-space: normal; background-color: rgb(255, 255, 255);\">Conflict Minerals (CM) refers to metals include but not limited to Gold (Au), Tantalum (Ta), Tungsten (W) , Tin (Sn) and cobalt(Co) from the democratic republic of Congo and its neighboring countries. Xiamen Sanan Integrated Circuit Co.,Ltd, China does not purchase the CM or support the use of CM. All suppliers of Xiamen Sanan Integrated Circuit Co.,Ltd, China are required not to purchase/use conflict minerals (CM); Suppliers are also requested to investigate the sources of metals , such as gold, tantalum,tungsten, tin and cobalt used in their products.</span></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879647', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('310', '20', 'QUALITY STRATEGY', '0', '', '62', '', '', '', '', '', '', '', '', '<p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><strong style=\";padding: 0px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Quality Policy:</span></span></strong><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\">Quality first, satisfy customers, produce stable quality, continuously improve quality.</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><strong style=\";padding: 0px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\">HSF Policy:</span></strong></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\">To comply with laws and ensure customers’ satisfaction, Sanan-IC&nbsp; commits to continuously reduce the HS of product through green production.</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><strong style=\";padding: 0px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Quality Management System:</span></span></strong><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\">To ensure the quality of products and service, Sanan-IC manages a series of processes like R&amp;D, production, delivery and customer service, including:</span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Evaluate technical development feasibility</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Implement FMEA and control plan</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Implement statistical process control during production(SPC)</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Total quality management in production process</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Monitor and control production equipment and environment</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Strictly control the quality of raw materials and shipping products</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Routine monitor product reliability</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;line-height: 16px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">◇</span></span><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Customer satisfaction survey, continuous improvement</span></span></span></span></span></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><strong style=\";padding: 0px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\">Total Quality Management System in Sanan-IC</span></strong></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><img alt=\"\" src=\"/ueditor/php/upload/image/20211022/1634879711774572.png\" style=\";padding: 0px;border: none;box-sizing: border-box;max-width: 100%;width: 800px;height: 463px\" _src=\"/ueditor/php/upload/image/20211022/1634879711774572.png\"/></p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\">&nbsp;</p><p style=\"margin-top: 0px;margin-bottom: 0px;padding: 0px;border: none;box-sizing: border-box;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: Calibri, sans-serif\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">Sanan-IC has obtained ISO9001, IATF16949</span></span>,&nbsp;<span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 15px\"><span style=\";padding: 0px;border: none;box-sizing: border-box\">QC080000, ISO22301, SA8000, ISO27001 management system certification to ensure management standardization and process standardization.</span></span></span></span></p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634879700', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('311', '10', 'Sanan IC Expands Foundry Manufacturing Services for the Global Optical Market', '0', '', '66', '20211022/e1ca18b495e1aad82ef5d8f78ebfbd6c.jpg', '', '', '', '', '', '', '<p>Worldwide launch increases access to Sanan IC’s leading foundry platform and technical expertise</p>', '<p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">SUNNYVALE, Calif., March 09, 2020 (GLOBE NEWSWIRE) -- SANAN INTEGRATED CIRCUIT CO., LTD. (Sanan IC), a world-class wafer foundry with an advanced compound semiconductor&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=XG2C19HOEl_Yh4d3ZKXJzAZZCLXurYS6EC-oKvEh9en0leh-UohTaKOWff8LooFbk36lZ7lvV3xB3Sc2J495gejx_U8MUDmluzD-i4sl8pQ=\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">technology platform</span></a>, today announced the worldwide expansion of its optical portfolio. Using the most advanced materials and foundry supply network, Sanan IC will provide the global optical market with large-scale foundry services for customized vertical-cavity surface-emitting lasers (VCSEL) and arrays, along with standard products for optical communication applications.</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">Sanan IC’s worldwide launch comes on the heels of LightCounting’s&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=41PA4CIlUnBCog3n8rfDBN08oyz5ejnOJDls8WIMEbMFT7YpieQdrFgvbR8_NoQP7n-M9BNP-taA9CvVCupEN75Z1JdMmiQ_E5Up80FcPrSrc27POyEW50_tLl-NA7hn1kKTEWrcIqNLO1htDtvXUeOafG_UyFTTHqcW_8PiYUkXd-HdBAQRABjIRya-nsidHuZwLp4c3Z3rRxEXszilRw==\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">report</span></a>&nbsp;that the optical transceiver market will rise at a 15% compound annual growth rate (CAGR) from 2020 through 2024. Additionally, Yole Développement (Yole) analysts expect the&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=AtpCKZlYLyV_Qg77-4dcGKGkAoalXuzjEQAm7nEgBPxAyI_0DomjWQ-n7NsyCBoE0igeANDqNL_TVrybGEZwc8fLRE0GU_Rr_hdDK5Y7hQrSB0R5vNURn5TKHSgAG_cOMRYoqIypunf9cMoqDAeAX1QyKj5EfNp9tJUhLX4vNyc=\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">global 3D imaging and sensing market</span></a>&nbsp;to expand from $5 billion in 2019 to $15 billion in 2025<sup style=\"margin: 0px; padding: 0px; box-sizing: border-box;\">1</sup>, at a 20% CAGR during this period.</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">“Our executive team recognizes the tremendous business opportunities in serving high-growth optical communication and consumer application markets,” says Raymond Cai, CEO of Sanan IC. “Cutting edge optical products and foundry services are paramount to accommodating the rapid adoption of automotive, big data and 5G wireless communications technologies. Sanan IC’s robust supply chain and state-of-the-art technology can meet these demands, which is why we are committed to making our components and services commercially available worldwide.”</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">With a broad range of wavelengths available in-house, Sanan IC enables fast, cost-effective design and manufacturing of high-power VCSEL lasers, high-speed VCSEL lasers, distributed feedback (DFB) lasers, avalanche photodiodes (APD) and monitor photodiodes (MPD). Experienced engineering teams and the industry’s most advanced process tools make Sanan IC capable of delivering leading turn-key solutions, all while maintaining the highest standards of quality and reliability. With the ability to ensure its supply chain, Sanan IC provides a dedicated capacity for gallium arsenide (GaAs) and indium phosphide (InP) epi growth, and epitaxial wafer fabrication on 2-inch, 4-inch and 6-inch platforms.</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><span style=\"margin: 0px; padding: 0px; font-weight: 600; box-sizing: border-box;\">Applications We Serve</span></span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">Sanan IC’s portfolio of optical manufacturing technology includes a family of high-power diode lasers that deliver high-brightness and provide exceptional reliability for a variety of markets, such as medical, datacom, telecom and printing. Additionally, Sanan IC offers a range of foundry services for numerous applications, including:</span></span></p><ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li style=\"\"><p><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">2D, 3D and proximity sensors, as well as illuminators for consumer and mobile</span></span></p></li><li style=\"\"><p><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">HDMI 2.0 and USB 3.0 active optical cables (AOC)</span></span></p></li><li style=\"\"><p><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">LiDAR</span></span></p></li><li style=\"\"><p><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">100G, 200G and 400G high-speed, high-capacity data center interconnect (DCI)</span></span></p></li><li style=\"\"><p><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">Fronthaul and backhaul 5G infrastructures</span></span></p></li></ul><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><span style=\"margin: 0px; padding: 0px; font-weight: 600; box-sizing: border-box;\">Sanan IC Attending 2020 Optical Communication Conference (OFC)</span></span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\">Sanan IC is attending OFC 2020, March 10-12 at the San Diego Convention Center. Sales representatives will be available to provide detailed information on Sanan IC’s optical foundry services and global expansion. To schedule a meeting, please contact&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=U91fKjrgnGpDQ25PBTltoa3LDFyJpIo3Ybf9RcAMeKubb9vW_KM7lEEHrKNJoDqq2rkguY6Jz1ITc74K730Pug==\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">ray@sanan-ic.com</span></a>.</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><sup style=\"margin: 0px; padding: 0px; box-sizing: border-box;\">1</sup>Source: 3D Imaging &amp; Sensing 2020 report, Yole Développement</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><span style=\"margin: 0px; padding: 0px; font-weight: 600; box-sizing: border-box;\">About Sanan IC</span><br/>Sanan Integrated Circuit Co., Ltd. (Sanan IC) is China’s first 6-inch compound semiconductor wafer foundry, serving the microelectronics and photonics markets worldwide. The company was founded in 2014 and is based in Xiamen City in the Fujian Province of China, operating as a subsidiary of Sanan Optoelectronics Co., Ltd. (SSE: 600703). The company develops and provides GaAs, GaN, SiC, and InP foundry services with its state-of-the-art III-V compound semiconductor fabrication facilities. Certified to the ISO9001 international quality standard, ISO14001 environmental management standard, and IATF 16949:2016 Automotive Quality Management System (QMS) standard, Sanan IC empowers the global community of RF, millimeter wave, filter, power electronics, and optical communications markets with its advanced process technology platform. Sanan IC is&nbsp;<em style=\"margin: 0px; padding: 0px; box-sizing: border-box;\">Dedicated to Driving Compound Semiconductor Innovation</em>.&nbsp;For more information, visit&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=fgevmKMRBGVQyoJ04JWroOysarU_aIYuC7XwshTRJ0DfzI4_PPl74gI8zD7tzzlYzM_hmD1fb5JPh4gj4ZWY3BiovH4gBsW1Yd04q5REm5s=\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">www.sanan-ic.com/en</span></a>.</span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><span style=\"margin: 0px; padding: 0px; font-weight: 600; box-sizing: border-box;\">Connect with Sanan IC</span><br/>LinkedIn:&nbsp;<a href=\"https://www.globenewswire.com/Tracker?data=SXLERMBP2MRZklvjyC3wFENUusMfinjxuxXELwbbua_xzNivUSIoSYEWmBxdbGJay1aEXh-BYcJBmuyYeyXQeA4l_WVHR9sjCfq9EzJnlUtRJQtG-fwqZV5ofv2Rhw1qeJDL56D0MRxvqdlRn9G8NlvpV5xpwCbzZ82f7nZ0hCi8Db5ZS_18fooypP0PHmtoW3tRUEyzu3O2k-xn_FUFWA==\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">www.linkedin.com/company/sanan-integrated-circuit-co-ltd/</span></a></span></span></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; color: rgb(83, 93, 96); line-height: 1.85; font-variant-numeric: normal; font-variant-east-asian: normal; white-space: normal; font-family: roboto, arial, sans-serif;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; line-height: 1;\"><span style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; font-size: 12px;\"><span style=\"margin: 0px; padding: 0px; font-weight: 600; box-sizing: border-box;\">Media Relations Contact</span><br/>Olivia Metcalfe<br/>Townsend Team<br/><a href=\"https://www.globenewswire.com/Tracker?data=b92R0jyfcZZvREuRKFdxazwwKmTxaU46kxIfY3fbouF0I7KnPxgI3CEbzdjPJYrgbSHNWFlIsL1RLghsmLP58OpuVgVqtV8zlqJNsvmWw5M=\" target=\"_blank\" title=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; color: rgb(86, 87, 87); font-weight: 700;\"><span style=\"text-decoration:underline;\">olivia@townsendteam.com</span></a></span></span></p><p><br/></p>', '8', '', '1', '0', '', '', '127.0.0.1', '1634880506', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('312', '20', 'SAIC’s statement on the impact of the 2019-nCov coronavirus pneumonia outbreak', '0', '', '66', '20211022/99526ce53fc4f37a11b3d381cf11693f.jpg', '', '', '', '', '', '', '', '<p style=\"margin-top: 0.36rem;margin-bottom: 0.36rem;padding: 1px 0px;border: none;box-sizing: border-box;font-size: 0.2rem;color: rgb(120, 123, 127);line-height: 1.85;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px;text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 等线\">The outbreak of new coronavirus pneumonia (2019-nCov) has draw widespread attention for the people all over the country and affected in normal operation of all walks of life. SAIC prioritizes epidemic management and the health of our employees. Meanwhile, in order to meet the demands from our customers and the market, SAIC is making continuous production arrangements within the company to minimize the impact of the epidemic. So far, no employees or their family members have been infected, and the company&#39;s production and supply chain operation kept operating normally. Customer order delivery was not affected.</span></span></p><p style=\"margin-top: 0.36rem;margin-bottom: 0.36rem;padding: 1px 0px;border: none;box-sizing: border-box;font-size: 0.2rem;color: rgb(120, 123, 127);line-height: 1.85;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px;text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 等线\">As a semiconductor IC manufacturing company, SAIC operates 24 hours a day and all days throughout the year. With the 2019-nCov outbreak, the company management quickly established BCM emergency working group before the Spring Festival and organized the epidemic prevention and control. Follow the government&#39;s guidance and supervision of epidemic prevention,we actively prevent and cope with the epidemic by using various channels to guide all staff on effectively self-prevention to ensure our employees&#39; health.</span></span></p><p style=\"margin-top: 0.36rem;margin-bottom: 0.36rem;padding: 1px 0px;border: none;box-sizing: border-box;font-size: 0.2rem;color: rgb(120, 123, 127);line-height: 1.85;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255);text-indent: 28px;text-align: justify\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 等线\">&nbsp;With the development of the epidemic, the company comprehensively checked the health status of our employees, arranged the delayed return to work , planned the relevant protective equipment reservation in advance, set up the company supervision system for isolation observation , built the security personnel list and encouraged our employees to work remotely,which all according to the guidance and requirements from relevant governments. In the meantime, we have strengthened the company&#39;s entry control and epidemic prevention publicity, including strict entrance personnel temperature monitoring, strengthen of the office area and business vehicles disinfection, food and beverage health management and also promoting the epidemic prevention related knowledge. &nbsp;</span></span></p><p style=\"margin-top: 0.36rem;margin-bottom: 0.36rem;padding: 1px 0px;border: none;box-sizing: border-box;font-size: 0.2rem;color: rgb(120, 123, 127);line-height: 1.85;font-family: Arial, Helvetica, sans-serif;letter-spacing: 1px;white-space: normal;background-color: rgb(255, 255, 255)\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-size: 14px\"><span style=\";padding: 0px;border: none;box-sizing: border-box;font-family: 等线\">Epidemic prevention is everyone&#39;s responsibility. SAIC regards employees as our most valuable assets and will give top priority to our employees’ health. Under the requirements of governments for epidemic prevention, our company combine with the actual situation , to secure the cleanness of our working environment comprehensively , ensure the health of our employees and keep the continuity of our production and operati</span></span></p><p><br/></p>', '24', '', '1', '0', 'Sanan', '', '127.0.0.1', '1634880620', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('313', '10', 'SANAN IC ANNOUNCES COMMERCIAL RELEASE OF 6-INCH SIC WAFER FOUNDRY PROCESS', '0', '', '67', '20211022/36be98b006f58ed3b58099fb66255db1.jpg', '', '', '', '', '', '', '<p>SUNNYVALE, Calif., Dec. 19, 2018 (GLOBE NEWSWIRE) -- SANAN INTEGRATED CIRCUIT CO., LTD. (Sanan IC), a pure-play wafer foundry with its advanced compound semiconductor technology platform.</p>', '<p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">Sunnyvale, Calif. – November 27, 2018– SANAN INTEGRATED CIRCUIT CO., LTD. (Sanan IC), a pure-play compound semiconductor foundry with its advanced III-V technology platform, today announced that it has attained additional certifications for its manufacturing management systems. The company recently earned IATF16949:2016 Automotive Quality Management System (QMS) certification, and this past June also completed ISO27001:2013 certification for Information Security Management standards compliance. These recent achievements are in addition to existing certifications which include ISO9001:2015 Quality Management and Assurance Systems, IECQ QC080000:2012 Hazardous Substance Process Management (HSPM), ISO140001:2015 Environmental Management Systems (EMS), and OHSAS 18001:2007 Occupational Health and Safety Management.</p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\"><img alt=\"\" src=\"http://demo.uunn.cn/sananjc/dist/image/new_005.jpg\" style=\"margin: 0.3rem auto; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; display: block;\"/></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">“We at Sanan IC are proud of having attained these key milestones of international standards compliance for Quality, Environmental and Information Technology (IT) management systems”, said Raymond Cai, Chief Executive Officer of Sanan IC. “Having these procedures and disciplines in place not only gives us a solid foundation to be a world-class, large-scale wafer manufacturer, but it also shows our company’s commitment to quality, security, and safety which our customers demand and which our employees expect. These management systems definitely helps us strive for constant improvements in efficiency, productivity, communications, and environmental awareness”.</p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">Sanan IC offers a broad portfolio of compound semiconductor wafer foundry services, namely for gallium arsenide (GaAs) HBT, pHEMT, BiHEMT, integrated passive device (IPD), filters, gallium nitride (GaN) power HEMT, silicon carbide (SiC), and indium phosphide (InP) intended for RF, millimeter wave, power electronics, and optical communications markets. Among the various applications for these process technologies is automotive such as for vehicle-to-everything (V2X) communications, collision-avoidance sensors, hybrid/electric vehicle (HEV/EV) charging and motor drives. With IATF 1694 compliance, Sanan IC’s customers are able to meet the automotive industry’s stringent quality system requirements.</p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\"><img alt=\"\" src=\"http://demo.uunn.cn/sananjc/dist/image/new_006.jpg\" style=\"margin: 0.3rem auto; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; display: block;\"/></p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">To mitigate information and intellectual property (IP) protection concerns, ISO27001 compliance facilitates best-practice for aninformation security management system (ISMS). It sets guidelines for implementing and monitoring security measures as well as for risk management of both the company’s and customers’ proprietary information and IP. Practicing and maintaining these security management procedures combined with the other quality and environmental systems lead to building and establishing customer confidence and trust.</p><p style=\"margin-top: 0.36rem; margin-bottom: 0.36rem; padding: 1px 0px; border: none; box-sizing: border-box; font-size: 0.2rem; color: rgb(120, 123, 127); line-height: 1.85; font-family: Arial, Helvetica, sans-serif; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">About Sanan IC<br/>Sanan Integrated Circuit Co., Ltd. (Sanan IC) is China’s first 6-inch compound semiconductor wafer foundry, serving the microelectronics and photonics markets worldwide. The company was founded in 2014, and is based in Xiamen City in the Fujian Province of&nbsp; China, operating as a subsidiary of Sanan Optoelectronics Co., Ltd. (SSE: 600703). The company develops and provides GaAs, GaN, SiC, and InP epitaxial wafers and substrates with its state-of-the-art III-V semiconductor fabrication facilities. Sanan IC empowers the global community of RF, millimeter wave, filter, power electronics, and optical communications markets with its advanced process technology platform. www.sanan-ic.com/en.</p><p><br/></p>', '6', '', '1', '0', '', '', '127.0.0.1', '1634881107', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('314', '10', 'Passed the quality management system (ISO 9001) certification', '0', '', '68', '20211022/d9099f9da23ca6d8e6916c093910cb7e.jpg', '', '', '', '', '', '', '', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634883364', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('315', '20', 'Passed the Hazardous substances process management system(IECQ QC080000) certification', '0', '', '68', '20211022/5859a349f682ac1f4f9d23685b9d7483.jpg', '', '', '', '', '', '', '', '', '0', '', '1', '0', '', '', '127.0.0.1', '1634883425', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('316', '10', 'Total Quality Management System in Sanan-IC', '0', '', '69', '', '', '', '', '', '', '', '', '<div class=\"at_on animated fadeInUpSmall\" style=\"margin: 0px; padding: 0.4rem 0px; border: none; box-sizing: border-box; animation-duration: 0.6s; animation-fill-mode: both; animation-name: fadeInUpSmall; visibility: visible; text-align: center; font-size: 0.4rem; line-height: 1.5; font-family: Conv_SAIRAEXTRACONDENSED-BOLD_1; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); animation-delay: 0s;\"><img class=\"at_on animated fadeInUpSmall\" src=\"/ueditor/php/upload/image/20211022/1634884306101344.png\" alt=\"\" _src=\"/ueditor/php/upload/image/20211022/1634884306101344.png\" style=\"font-size: 16px; margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; animation-duration: 0.6s; animation-fill-mode: both; animation-name: fadeInUpSmall; visibility: visible; display: block; width: 1140px; font-family: SEMIBOLD; animation-delay: 0.5s;\"/></div><p><img class=\"at_on animated fadeInUpSmall\" src=\"/ueditor/php/upload/image/20211022/1634884306126948.png\" alt=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; animation-duration: 0.6s; animation-fill-mode: both; animation-name: fadeInUpSmall; visibility: visible; display: block; width: 1140px; font-family: SEMIBOLD; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); animation-delay: 1s;\" _src=\"/ueditor/php/upload/image/20211022/1634884306126948.png\"/><img class=\"at_on animated fadeInUpSmall\" src=\"/ueditor/php/upload/image/20211022/1634884306294552.png\" alt=\"\" style=\"margin: 0px; padding: 0px; border: none; box-sizing: border-box; max-width: 100%; animation-duration: 0.6s; animation-fill-mode: both; animation-name: fadeInUpSmall; visibility: visible; display: block; width: 1140px; font-family: SEMIBOLD; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255); animation-delay: 1.5s;\" _src=\"/ueditor/php/upload/image/20211022/1634884306294552.png\"/></p><p><br/></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634884303', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `core_article` VALUES ('317', '10', 'We promise not to purchase Conflict Minerals CM.', '0', '', '70', '20211022/e73bf154681856aa11dfbb02e9631598.jpg', '', '', '', '', '', '', '', '<p><span style=\"color: rgb(98, 107, 122); font-family: SEMIBOLD; letter-spacing: 1px; white-space: normal; background-color: rgb(255, 255, 255);\">Conflict Minerals (CM) refers to metals include but not limited to Gold (Au), Tantalum (Ta), Tungsten (W) , Tin (Sn) and cobalt(Co) from the democratic republic of Congo and its neighboring countries. Xiamen Sanan Integrated Circuit Co.,Ltd, China does not purchase the CM or support the use of CM. All suppliers of Xiamen Sanan Integrated Circuit Co.,Ltd, China are required not to purchase/use conflict minerals (CM); Suppliers are also requested to investigate the sources of metals , such as gold, tantalum,tungsten, tin and cobalt used in their products.</span></p>', '0', '', '1', '0', '', '', '127.0.0.1', '1634884822', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `core_article_cate`
-- -----------------------------
DROP TABLE IF EXISTS `core_article_cate`;
CREATE TABLE `core_article_cate` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `en_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `orderby` int(11) DEFAULT '100' COMMENT '排序',
  `info_state` tinyint(5) NOT NULL DEFAULT '0',
  `website` varchar(200) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `wap_photo` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `wap_website` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `is_Target` tinyint(2) DEFAULT NULL,
  `is_nav` tinyint(2) DEFAULT NULL,
  `seo_title` text,
  `keyword` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `fields` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `classification_ids` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `catedir` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_bigpic` int(5) DEFAULT '0',
  `is_annex` int(5) DEFAULT '0',
  `is_intro` int(5) DEFAULT '0',
  `is_video` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_piclist` int(5) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_article_cate`
-- -----------------------------
INSERT INTO `core_article_cate` VALUES ('41', 'ABOUT SAIC', 'ABOUT SAIC', '0', '0', '20', '1', '', '', '', '', '', '1634709396', '1634721235', '1', '', '', '', '', '', '17,19', '', '', '0', '0', '0', '', '1');
INSERT INTO `core_article_cate` VALUES ('42', 'TECHNOLOGY PLATFORM', 'TECHNOLOGY PLATFORM', '0', '0', '30', '2', '', '', '', '', '', '1634709423', '1634793274', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('43', 'MANAGEMENT', 'MANAGEMENT', '0', '0', '40', '3', '', '', '', '', '', '1634709436', '1634870082', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('44', 'NEWS AND CULTURE', 'NEWS AND CULTURE', '0', '0', '50', '4', '', '', '', '', '', '1634709449', '1634882210', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('45', 'QUALITY MANAGEMENT', 'QUALITY MANAGEMENT', '0', '0', '60', '1', '', '', '', '', '', '1634709457', '1634709457', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('46', 'HUMAN RESOURCES', 'HUMAN RESOURCES', '0', '0', '70', '1', 'http://hr.sanan-ic.com/en/', '', '', '', '', '1634709467', '1634710137', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('47', 'HOME', 'HOME', '0', '0', '10', '1', '', '', '', '', '', '1634711149', '1634714436', '1', '', '', '', '', '', '', '', '', '0', '1', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('48', 'Video_banner', '', '47', '0', '10', '1', '', '', '', '', '', '1634714234', '1634714444', '1', '', '', '', '', '', '', '', '', '0', '1', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('49', 'Pop_video', '', '47', '0', '20', '1', '', '', '', '', '', '1634714290', '1634714449', '1', '', '', '', '', '', '', '', '', '0', '1', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('50', 'Company Profile', '', '41', '0', '10', '1', '', '', '', '', '', '1634720012', '1634799769', '1', '', '', '', '', '', '1,17,19', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('51', 'Vision', '', '41', '0', '20', '1', '', '', '', '', '', '1634720035', '1634720062', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('52', 'Milestone', '', '41', '0', '30', '1', '', '', '', '', '', '1634720053', '1634720053', '1', '', '', '', '', '', '1', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('53', 'Radio Frequency', 'In the field of Radio Frequancy', '42', '0', '10', '2', '', '', '', '', '20211021/b0b69b93cfcaa6fc83bfd61f6bbe3580.jpg', '1634785367', '1634794189', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('54', 'Power Electronics', 'In the field of Power Electronics', '42', '0', '20', '2', '', '', '', '', '20211021/357b63f35307db306dbed2549102116c.jpg', '1634785390', '1634794075', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('55', ' Optical Devices', 'In the field of optical communication', '42', '0', '30', '2', '', '', '', '', '20211021/d22d830091f047cd5024f418a73ed491.png', '1634785399', '1634794099', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('56', 'Company Profile', '', '50', '0', '10', '1', '', '', '', '', '', '1634799835', '1634799835', '1', '', '', '', '', '', '17,19', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('57', 'GaAs', '', '53', '0', '10', '2', '', '', '', '', '', '1634867344', '1634888194', '1', '', '', '', '', '', '', '', '', '1', '1', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('71', ' SAW Filter', '', '53', '0', '20', '2', '', '', '', '', '', '1634888209', '1634888209', '1', '', '', '', '', '', '', '', '', '1', '1', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('59', 'Foundry Services Process', '', '54', '0', '10', '2', '', '', '', '', '', '1634868355', '1634888230', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('60', 'Foundry Services', '', '55', '0', '10', '2', '', '', '', '', '', '1634868371', '1634888256', '1', '', '', '', '', '', '', '', '', '1', '1', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('61', 'ESH System', '', '43', '0', '10', '3', '', '', '', '', '', '1634870503', '1634870503', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('62', ' Quality System', '', '43', '0', '20', '3', '', '', '', '', '', '1634870519', '1634882484', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('63', 'Introduction', '', '61', '0', '10', '3', '', '', '', '', '', '1634871105', '1634882458', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('64', 'Information', '', '61', '0', '20', '3', '', '', '', '', '', '1634871122', '1634882466', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('65', 'Events', '', '61', '0', '30', '3', '', '', '', '', '', '1634871132', '1634882475', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('66', 'News', '', '44', '0', '10', '4', '', '', '', '', '', '1634880035', '1634882222', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('67', ' Corporate Culture', '', '44', '0', '20', '4', '', '', '', '', '', '1634880051', '1634882235', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('68', 'System Certification', '', '45', '0', '10', '5', '', '', '', '', '', '1634881934', '1634881934', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('69', 'Quality Strategy', '', '45', '0', '20', '5', '', '', '', '', '', '1634881946', '1634881946', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('70', 'Promise Of Conflict Minerals CM', '', '45', '0', '30', '5', '', '', '', '', '', '1634881959', '1634881959', '1', '', '', '', '', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `core_article_cate` VALUES ('72', 'Solutions', '', '54', '0', '20', '2', '', '', '', '', '', '1634888240', '1634888240', '1', '', '', '', '', '', '', '', '', '1', '0', '1', '', '1');
INSERT INTO `core_article_cate` VALUES ('73', 'Solutions', '', '55', '0', '20', '2', '', '', '', '', '', '1634888267', '1634888267', '1', '', '', '', '', '', '', '', '', '1', '1', '1', '', '1');

-- -----------------------------
-- Table structure for `core_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `core_attribute`;
CREATE TABLE `core_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortnum` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `create_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;


-- -----------------------------
-- Table structure for `core_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `core_auth_group`;
CREATE TABLE `core_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_auth_group`
-- -----------------------------
INSERT INTO `core_auth_group` VALUES ('1', '系统管理员', '1', '1,2,3,61,88,89,90,5,6,27,13,14,24,25,26,48,81,82,83,85,87,84,70,91,71,75,92,93,96,97,98,115,116,117', '1446535750', '1520211372');
INSERT INTO `core_auth_group` VALUES ('2', '内容管理员', '1', '1,2,3,61,94,95,5,6,27,13,14,24,25,26,48,81,82,70,71,75,92,93,96,97,98', '1446535750', '1531301016');

-- -----------------------------
-- Table structure for `core_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `core_auth_group_access`;
CREATE TABLE `core_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_auth_group_access`
-- -----------------------------
INSERT INTO `core_auth_group_access` VALUES ('1', '1');
INSERT INTO `core_auth_group_access` VALUES ('9', '2');

-- -----------------------------
-- Table structure for `core_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `core_auth_rule`;
CREATE TABLE `core_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_auth_rule`
-- -----------------------------
INSERT INTO `core_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '40', '1446535750', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('5', '#', '数据库管理', '1', '0', 'fa fa-database', '', '0', '50', '1446535750', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('6', 'admin/data/index', '数据库备份', '1', '0', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('13', '#', '日志管理', '1', '0', 'fa fa-tasks', '', '0', '60', '1477312169', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('14', 'admin/log/operate_log', '行为日志', '1', '0', '', '', '13', '50', '1477312169', '1477312169');
INSERT INTO `core_auth_rule` VALUES ('24', '#', '文章管理', '1', '1', 'fa fa-paste', '', '0', '20', '1477312169', '1535340122');
INSERT INTO `core_auth_rule` VALUES ('25', 'admin/article/index_cate', '栏目分类', '1', '1', '', '', '24', '10', '1477312260', '1547544024');
INSERT INTO `core_auth_rule` VALUES ('26', 'admin/article/index', '文章列表', '1', '1', '', '', '24', '20', '1477312333', '1535340145');
INSERT INTO `core_auth_rule` VALUES ('27', 'admin/data/import', '数据库还原', '1', '0', '', '', '5', '50', '1477639870', '1477639870');
INSERT INTO `core_auth_rule` VALUES ('48', '#', '广告管理', '1', '1', 'fa fa-image', '', '0', '30', '1477640011', '1477640011');
INSERT INTO `core_auth_rule` VALUES ('81', 'admin/ad/index_position', '广告位', '1', '0', '', '', '48', '50', '1517022329', '1517022329');
INSERT INTO `core_auth_rule` VALUES ('82', 'admin/ad/index', '广告列表', '1', '1', '', '', '48', '50', '1517022352', '1517022352');
INSERT INTO `core_auth_rule` VALUES ('61', 'admin/config/index', '系统配置', '1', '0', '', '', '1', '50', '1479908607', '1527832715');
INSERT INTO `core_auth_rule` VALUES ('70', '#', '会员管理', '1', '0', 'fa fa-user-circle-o', '', '0', '10', '1484103066', '1528095832');
INSERT INTO `core_auth_rule` VALUES ('71', 'admin/member/group', '会员组', '1', '0', '', '', '70', '20', '1484103304', '1528096076');
INSERT INTO `core_auth_rule` VALUES ('75', 'admin/member/index', '会员列表', '1', '0', '', '', '70', '10', '1484103304', '1484103304');
INSERT INTO `core_auth_rule` VALUES ('92', '#', '功能管理', '1', '1', 'fa fa fa-legal', '', '0', '35', '1519872916', '1528098816');
INSERT INTO `core_auth_rule` VALUES ('93', 'admin/message/index', '留言管理', '1', '0', '', '', '92', '20', '1519872954', '1528098912');
INSERT INTO `core_auth_rule` VALUES ('94', 'admin/website/index', '网站配置', '1', '1', '', '', '1', '10', '1527835580', '1527835580');
INSERT INTO `core_auth_rule` VALUES ('95', 'admin/counter/index', '访问统计', '1', '1', '', '', '1', '50', '1527924894', '1527924894');
INSERT INTO `core_auth_rule` VALUES ('100', 'admin/nature/cate', '链接分类', '1', '0', '', '', '92', '50', '1532058065', '1532058065');
INSERT INTO `core_auth_rule` VALUES ('101', 'admin/nature/index', '链接列表', '1', '1', '', '', '92', '50', '1532058093', '1532058093');
INSERT INTO `core_auth_rule` VALUES ('102', '#', '内容批量处理', '1', '1', 'fa fa-legal ', '', '0', '50', '1532081423', '1532081454');
INSERT INTO `core_auth_rule` VALUES ('103', 'admin/batch/batchupload', '信息批量上传', '1', '1', '', '', '102', '1', '1532081526', '1532081526');
INSERT INTO `core_auth_rule` VALUES ('104', 'admin/batch/move', ' 批量转移', '1', '1', '', '', '102', '50', '1532081555', '1532081555');
INSERT INTO `core_auth_rule` VALUES ('105', 'admin/batch/watermark', '批量水印', '1', '1', '', '', '102', '50', '1532081582', '1532081582');
INSERT INTO `core_auth_rule` VALUES ('106', 'admin/batch/replace', '批量替换', '1', '1', '', '', '102', '50', '1532081610', '1532081610');
INSERT INTO `core_auth_rule` VALUES ('107', 'admin/weixin/index', '微信配置', '1', '0', '', '', '1', '50', '1538035879', '1538035879');
INSERT INTO `core_auth_rule` VALUES ('108', 'admin/wx_member/index', '微信会员', '1', '0', '', '', '70', '50', '1542334651', '1542334651');
INSERT INTO `core_auth_rule` VALUES ('109', 'admin/article/article_recycle', '回收站', '1', '1', '', '', '24', '50', '1542961855', '1542961855');
INSERT INTO `core_auth_rule` VALUES ('110', 'admin/querlist/index', '抓取网站数据', '1', '0', '', '', '1', '50', '1547629860', '1547629860');
INSERT INTO `core_auth_rule` VALUES ('111', 'admin/fields/index', '新增新闻字段', '1', '0', '', '', '1', '50', '1557368380', '1557368380');
INSERT INTO `core_auth_rule` VALUES ('112', 'admin/floating/index', '漂浮窗', '1', '0', '', '', '92', '50', '1560993700', '1560993700');
INSERT INTO `core_auth_rule` VALUES ('113', 'admin/online/index', '在线客服', '1', '0', '', '', '92', '50', '1561944795', '1561944795');
INSERT INTO `core_auth_rule` VALUES ('115', '#', '属性管理', '1', '0', 'fa fa-cubes', '', '0', '50', '1583119681', '1583119681');
INSERT INTO `core_auth_rule` VALUES ('116', 'admin/classification/index', '属性分类', '1', '0', '', '', '115', '50', '1583119845', '1583119845');
INSERT INTO `core_auth_rule` VALUES ('117', 'admin/attribute/index', '属性列表', '1', '0', '', '', '115', '50', '1583140434', '1583140434');
INSERT INTO `core_auth_rule` VALUES ('118', 'admin/apply/job_index', '人才招聘', '1', '1', '', '', '92', '50', '1629179481', '1629179481');

-- -----------------------------
-- Table structure for `core_cate_config`
-- -----------------------------
DROP TABLE IF EXISTS `core_cate_config`;
CREATE TABLE `core_cate_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_cate_config`
-- -----------------------------
INSERT INTO `core_cate_config` VALUES ('1', 'en_name', '1');
INSERT INTO `core_cate_config` VALUES ('2', 'catedir', '0');
INSERT INTO `core_cate_config` VALUES ('3', 'website', '1');
INSERT INTO `core_cate_config` VALUES ('4', 'photo', '1');
INSERT INTO `core_cate_config` VALUES ('5', 'wap_photo', '0');
INSERT INTO `core_cate_config` VALUES ('6', 'pic', '1');
INSERT INTO `core_cate_config` VALUES ('7', 'info_state', '1');
INSERT INTO `core_cate_config` VALUES ('8', 'target', '0');
INSERT INTO `core_cate_config` VALUES ('9', 'nav', '0');
INSERT INTO `core_cate_config` VALUES ('10', 'other', '1');
INSERT INTO `core_cate_config` VALUES ('11', 'pic_list', '1');
INSERT INTO `core_cate_config` VALUES ('12', 'wzjl', '0');
INSERT INTO `core_cate_config` VALUES ('17', 'wap_website', '0');

-- -----------------------------
-- Table structure for `core_classification`
-- -----------------------------
DROP TABLE IF EXISTS `core_classification`;
CREATE TABLE `core_classification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortnum` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `style` tinyint(2) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `create_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;


-- -----------------------------
-- Table structure for `core_config`
-- -----------------------------
DROP TABLE IF EXISTS `core_config`;
CREATE TABLE `core_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_config`
-- -----------------------------
INSERT INTO `core_config` VALUES ('1', 'web_site_close', '1');
INSERT INTO `core_config` VALUES ('2', 'list_rows', '10');
INSERT INTO `core_config` VALUES ('3', 'admin_allow_ip', '');
INSERT INTO `core_config` VALUES ('13', 'web_weixin_close', '0');
INSERT INTO `core_config` VALUES ('14', 'wap_site_state', '1');
INSERT INTO `core_config` VALUES ('15', 'wap_site_domain', '');

-- -----------------------------
-- Table structure for `core_counter`
-- -----------------------------
DROP TABLE IF EXISTS `core_counter`;
CREATE TABLE `core_counter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=958 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `core_counter`
-- -----------------------------
INSERT INTO `core_counter` VALUES ('2', '', '', '1584517530', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('1', '', '', '1583195996', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('3', '电脑端', '', '1585188354', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('4', '电脑端', '', '1590374932', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('5', '电脑端', '', '1591338123', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('6', '电脑端', '', '1598859013', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('7', '电脑端', '', '1601255505', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('8', '电脑端', '', '1629164859', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('9', '电脑端', 'http://jingxiulaws.net/cfwl_system.php/index/index.html', '1629168967', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('10', '电脑端', 'http://jingxiulaws.net/home/category/index/id/2.html', '1629179304', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('11', '电脑端', 'http://jingxiulaws.net/cfwl_system.php', '1629186461', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('12', '电脑端', '', '1630114838', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('13', '电脑端', '', '1630119085', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('14', '电脑端', 'http://my.shsfkj.com/home/category/index/id/9.html', '1630129697', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('15', '电脑端', 'http://my.shsfkj.com/home/category/index/id/9.html', '1630133425', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('16', '电脑端', 'http://my.shsfkj.com/', '1630137160', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('17', '电脑端', 'http://my.shsfkj.com/home/category/index/id/1.html', '1630140945', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('18', '电脑端', '', '1630285320', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('19', '电脑端', 'http://my.shsfkj.com/', '1630289191', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('20', '电脑端', 'http://my.shsfkj.com/home/category/index/id/1.html', '1630292877', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('21', '电脑端', 'http://my.shsfkj.com/home/category/index/id/4.html', '1630301615', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('22', '电脑端', 'http://my.shsfkj.com/home/category/index/id/11.html', '1630305221', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('23', '电脑端', 'http://my.shsfkj.com/home/category/index/id/1.html', '1630308843', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('24', '电脑端', 'http://my.shsfkj.com/home/category/index/id/13.html', '1630312664', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('25', '电脑端', 'http://my.shsfkj.com/home/category/index/id/3.html', '1630316580', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('26', '电脑端', 'http://my.shsfkj.com/home/category/index/id/5.html', '1630369919', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('27', '电脑端', 'http://my.shsfkj.com/home/category/index/id/18.html', '1630373518', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('28', '电脑端', 'http://my.shsfkj.com/home/category/detail/id/90.html', '1630377312', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('29', '电脑端', 'http://my.shsfkj.com/home/category/index/id/14.html', '1630380948', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('30', '电脑端', 'http://my.shsfkj.com/home/category/detail/id/89.html', '1630387998', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('31', '电脑端', 'http://my.shsfkj.com/home/category/index/id/5.html', '1630391673', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('32', '电脑端', 'http://my.shsfkj.com/home/category/index/id/1.html', '1630395454', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('33', '电脑端', 'http://my.shsfkj.com/home/category/index/id/5.html', '1630399173', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('34', '电脑端', 'http://my.shsfkj.com/home/category/index/id/5.html', '1630402882', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('35', '电脑端', '', '1630456343', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('36', '电脑端', 'http://my.shsfkj.com/home/category/index/id/5.html', '1630460328', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('37', '电脑端', 'http://my.shsfkj.com/home/category/index/id/4.html', '1630464109', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('38', '电脑端', 'http://my.shsfkj.com/home/category/index/id/3.html', '1630467793', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('39', '电脑端', '', '1630468132', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('40', '电脑端', 'http://my.shsfkj.com/home/category/index/id/3.html', '1630474396', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('41', '手机端', 'http://my.shsfkj.com/mobile/index.html', '1630478108', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('42', '手机端', 'http://my.shsfkj.com/mobile', '1630481709', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('43', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/3.html', '1630485441', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('44', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/19.html', '1630489054', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('45', '电脑端', '', '1630542727', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('46', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/4.html', '1630546373', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('47', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/1.html', '1630549985', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('48', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/14.html', '1630553734', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('49', '手机端', 'http://my.shsfkj.com/mobile/category/index/id/3.html', '1630561203', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('50', '手机端', '', '1630561306', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('51', '电脑端', 'http://my.shsfkj.com/', '1630564803', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('52', '电脑端', 'http://my.shsfkj.com/home/category/index/id/1.html', '1630569778', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('53', '电脑端', 'http://my.shsfkj.com/cfwl_system.php/index/index.html', '1630573743', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('54', '电脑端', '', '1630889939', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('55', '电脑端', '', '1630891889', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('56', '电脑端', 'http://my.binhugroup.com/', '1630895723', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('57', '电脑端', 'http://my.binhugroup.com/', '1630899449', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('58', '电脑端', 'http://my.binhugroup.com/', '1630906422', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('59', '电脑端', 'http://my.binhugroup.com/', '1630910028', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('60', '电脑端', 'http://my.binhugroup.com/', '1630913641', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('61', '电脑端', 'http://my.binhugroup.com/home/category/index/id/1.html', '1630917267', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('62', '电脑端', 'http://my.binhugroup.com/home/category/index/id/1.html', '1630921866', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('63', '电脑端', '', '1630974608', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('64', '电脑端', 'http://my.binhugroup.com/home/category/index/id/1.html', '1630978606', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('65', '电脑端', 'http://my.binhugroup.com/home/category/index/id/9.html', '1630982449', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('66', '电脑端', 'http://my.binhugroup.com/home/category/detail/id/170.html', '1630986096', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('67', '电脑端', 'http://my.binhugroup.com/home/category/index/id/21.html', '1630992851', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('68', '电脑端', 'http://my.binhugroup.com/home/category/index/id/17.html', '1630996500', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('69', '电脑端', 'http://my.binhugroup.com/home/category/detail/id/168.html', '1631000157', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('70', '电脑端', 'http://my.binhugroup.com/', '1631003803', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('71', '电脑端', 'http://my.binhugroup.com/', '1631007519', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('72', '电脑端', '', '1631060991', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('73', '电脑端', 'http://my.binhugroup.com/home/category/index/id/1.html', '1631064763', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('74', '电脑端', 'http://my.binhugroup.com/home/category/index/id/17.html', '1631068515', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('75', '电脑端', 'http://my.binhugroup.com/home/category/index/id/9.html', '1631072137', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('76', '电脑端', 'http://my.binhugroup.com/', '1631079327', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('77', '电脑端', 'http://my.binhugroup.com/home/category/index/id/21.html', '1631082930', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('78', '电脑端', 'http://my.binhugroup.com/home/category/index/id/9.html', '1631086633', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('79', '电脑端', 'http://my.binhugroup.com/home/category/index/id/13.html', '1631090380', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('80', '电脑端', 'http://my.binhugroup.com/home/category/index/id/38.html', '1631094219', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('81', '电脑端', '', '1631147767', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('82', '电脑端', 'http://my.binhugroup.com/home/category/index/id/40.html', '1631151383', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('83', '电脑端', 'http://my.binhugroup.com/', '1631155178', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('84', '电脑端', 'http://my.binhugroup.com/home/category/index/id/2.html', '1631158779', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('85', '电脑端', 'http://my.binhugroup.com/home/category/index/id/3.html', '1631165640', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('86', '电脑端', 'http://my.binhugroup.com/home/category/index/id/40.html', '1631169261', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('87', '电脑端', 'http://my.binhugroup.com/home/category/detail/id/228.html', '1631173051', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('88', '电脑端', 'http://my.binhugroup.com/home/category/index/id/2.html', '1631176652', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('89', '电脑端', 'http://my.binhugroup.com/', '1631180391', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('90', '电脑端', 'http://my.binhugroup.com/home/category/index/id/28.html', '1631234020', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('91', '电脑端', 'http://my.binhugroup.com/home/category/index/id/2.html', '1631237737', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('92', '电脑端', 'http://my.sanan-ic.com/', '1634711950', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('93', '电脑端', 'http://my.sanan-ic.com/', '1634716435', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('94', '电脑端', 'http://my.sanan-ic.com/', '1634720454', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('95', '电脑端', 'http://my.sanan-ic.com/cfwl_system.php/index/index.html', '1634776802', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('96', '电脑端', 'http://my.sanan-ic.com/cfwl_system.php/index/index.html', '1634781282', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('97', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/51.html', '1634785184', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('98', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/50.html', '1634793359', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('99', '电脑端', 'http://my.sanan-ic.com/cfwl_system.php/index/index.html', '1634797841', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('100', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/51.html', '1634801563', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('101', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/50.html', '1634805291', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('102', '电脑端', 'http://my.sanan-ic.com/cfwl_system.php/index/index.html', '1634862983', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('103', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/54.html', '1634867661', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('104', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/62.html', '1634871316', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('105', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/63.html', '1634879210', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('106', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/62.html', '1634882877', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('107', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/44.html', '1634886478', '127.0.0.1', '0');
INSERT INTO `core_counter` VALUES ('108', '电脑端', 'http://my.sanan-ic.com/home/category/index/id/53.html', '1634890162', '127.0.0.1', '0');

-- -----------------------------
-- Table structure for `core_floating`
-- -----------------------------
DROP TABLE IF EXISTS `core_floating`;
CREATE TABLE `core_floating` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `link_url` varchar(128) DEFAULT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `ad_position` int(10) DEFAULT NULL,
  `mode` varchar(200) DEFAULT NULL,
  `width` int(10) DEFAULT NULL,
  `height` int(10) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_date` int(11) DEFAULT NULL COMMENT '结束时间',
  `asidetop` int(10) DEFAULT NULL,
  `asideleft` int(10) DEFAULT NULL,
  `screen_time` int(10) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `closed` tinyint(1) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_floating`
-- -----------------------------
INSERT INTO `core_floating` VALUES ('2', 'cs', '1', '20190617/a62340fa5774f3c35b05ab6c40300f62.png', '1', 'hangL', '150', '150', '1559318400', '1564502400', '200', '5', '4', '0', '1', '10');

-- -----------------------------
-- Table structure for `core_job`
-- -----------------------------
DROP TABLE IF EXISTS `core_job`;
CREATE TABLE `core_job` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateId` int(10) unsigned DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `sortnum` int(10) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `graduate_time` varchar(50) DEFAULT NULL,
  `college` varchar(50) DEFAULT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `resumes` text,
  `appraise` text,
  `create_time` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `major` varchar(50) DEFAULT NULL,
  `cate_name` varchar(50) DEFAULT NULL,
  `annex` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `core_log`
-- -----------------------------
DROP TABLE IF EXISTS `core_log`;
CREATE TABLE `core_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3796 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `core_member`
-- -----------------------------
DROP TABLE IF EXISTS `core_member`;
CREATE TABLE `core_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(32) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `sex` int(10) DEFAULT NULL COMMENT '1男2女',
  `password` char(32) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `head_img` varchar(200) DEFAULT NULL,
  `realname` varchar(32) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL COMMENT '认证的手机号码',
  `create_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `login_num` varchar(15) DEFAULT NULL COMMENT '登录次数',
  `status` tinyint(1) DEFAULT NULL COMMENT '1正常  0 禁用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `core_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `core_member_group`;
CREATE TABLE `core_member_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '留言Id',
  `group_name` varchar(32) NOT NULL COMMENT '留言评论作者',
  `status` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL COMMENT '留言回复时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COMMENT='文章评论表';

-- -----------------------------
-- Records of `core_member_group`
-- -----------------------------
INSERT INTO `core_member_group` VALUES ('1', '普通会员', '1', '1441616559', '1528097175');
INSERT INTO `core_member_group` VALUES ('2', '高级会员', '1', '1441617195', '1528097192');
INSERT INTO `core_member_group` VALUES ('3', 'VIP会员', '1', '1441769224', '1528097200');

-- -----------------------------
-- Table structure for `core_message`
-- -----------------------------
DROP TABLE IF EXISTS `core_message`;
CREATE TABLE `core_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sortnum` int(10) unsigned DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `reply` text COLLATE utf8_unicode_ci,
  `create_time` int(11) NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -----------------------------
-- Table structure for `core_nature`
-- -----------------------------
DROP TABLE IF EXISTS `core_nature`;
CREATE TABLE `core_nature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `pic` varchar(200) DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `nature_id` int(11) NOT NULL,
  `sortnum` int(11) NOT NULL DEFAULT '0',
  `create_time` varchar(200) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `core_nature`
-- -----------------------------
INSERT INTO `core_nature` VALUES ('1', '百度', '', 'http://www.baidu.com', '1', '10', '1547620706', '1');

-- -----------------------------
-- Table structure for `core_nature_cate`
-- -----------------------------
DROP TABLE IF EXISTS `core_nature_cate`;
CREATE TABLE `core_nature_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortnum` int(11) NOT NULL DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `core_nature_cate`
-- -----------------------------
INSERT INTO `core_nature_cate` VALUES ('1', '1', '友情链接');

-- -----------------------------
-- Table structure for `core_online_config`
-- -----------------------------
DROP TABLE IF EXISTS `core_online_config`;
CREATE TABLE `core_online_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_online_config`
-- -----------------------------
INSERT INTO `core_online_config` VALUES ('1', 'status', '0');
INSERT INTO `core_online_config` VALUES ('2', 'position', 'right');
INSERT INTO `core_online_config` VALUES ('3', 'show_btn', '1');
INSERT INTO `core_online_config` VALUES ('4', 'topSpace', '200');
INSERT INTO `core_online_config` VALUES ('5', 'width', '160');
INSERT INTO `core_online_config` VALUES ('6', 'bgcolor', '#FFFFFF');
INSERT INTO `core_online_config` VALUES ('8', 'title', '在线客服');
INSERT INTO `core_online_config` VALUES ('9', 'qrcode', '');
INSERT INTO `core_online_config` VALUES ('10', 'content', '<p style=\"text-align: center;\">联系电话</p><h6 style=\"text-align: center;\"><strong><span style=\"font-size: 16px;\">18600588099</span></strong></h6>');
INSERT INTO `core_online_config` VALUES ('7', 'serviceLine', '');
INSERT INTO `core_online_config` VALUES ('11', 'titcolor', '#FFFFFF');
INSERT INTO `core_online_config` VALUES ('12', 'titbgcolor', '#262626');
INSERT INTO `core_online_config` VALUES ('13', 'color', '#555555');
INSERT INTO `core_online_config` VALUES ('14', 'is_open', '0');

-- -----------------------------
-- Table structure for `core_online_list`
-- -----------------------------
DROP TABLE IF EXISTS `core_online_list`;
CREATE TABLE `core_online_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sortnum` int(10) unsigned NOT NULL,
  `number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_icon` int(10) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `core_online_list`
-- -----------------------------
INSERT INTO `core_online_list` VALUES ('1', '1', '26216125', '在线客服', '1', '1');

-- -----------------------------
-- Table structure for `core_pic_catelist`
-- -----------------------------
DROP TABLE IF EXISTS `core_pic_catelist`;
CREATE TABLE `core_pic_catelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `sortnum` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=gbk;


-- -----------------------------
-- Table structure for `core_pic_list`
-- -----------------------------
DROP TABLE IF EXISTS `core_pic_list`;
CREATE TABLE `core_pic_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `sortnum` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `core_pic_list`
-- -----------------------------
INSERT INTO `core_pic_list` VALUES ('12', '275', '1', '20190249471115964', '20211020/3cc1d7d37d48ab99d02d77e108f735d8.jpg', '');
INSERT INTO `core_pic_list` VALUES ('13', '275', '2', '1550645600617', '20211020/b5557451674e8474790a23af2e26853a.jpg', '');
INSERT INTO `core_pic_list` VALUES ('14', '275', '3', '1550645608084', '20211020/3e8e0742ebf5195fd0990b1a1f29e53a.jpg', '');
INSERT INTO `core_pic_list` VALUES ('15', '277', '1', '20190170284213136', '20211021/f937f9e1f923f3b7f5cefa6b3a9f6e68.jpg', '');
INSERT INTO `core_pic_list` VALUES ('16', '277', '2', '2019014524142745', '20211021/7434189cca687ea09f201315927d1b78.jpg', '');
INSERT INTO `core_pic_list` VALUES ('17', '277', '3', '20190160410213136', '20211021/65298b1c75a7cbb524fe0358ef564574.jpg', '');

-- -----------------------------
-- Table structure for `core_watermark`
-- -----------------------------
DROP TABLE IF EXISTS `core_watermark`;
CREATE TABLE `core_watermark` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_watermark`
-- -----------------------------
INSERT INTO `core_watermark` VALUES ('1', 'wm_type', '1');
INSERT INTO `core_watermark` VALUES ('2', 'wm_position', '3');
INSERT INTO `core_watermark` VALUES ('3', 'wm_text', '晨飞网络');
INSERT INTO `core_watermark` VALUES ('4', 'wm_fontfamily', 'ARIAL.TTF');
INSERT INTO `core_watermark` VALUES ('5', 'wm_fontsize', '18');
INSERT INTO `core_watermark` VALUES ('6', 'wm_color', '#363636');
INSERT INTO `core_watermark` VALUES ('7', 'wm_textquality', '75');
INSERT INTO `core_watermark` VALUES ('8', 'wm_image', '20180721/1793529026c8ecf744fe9149c7be6299.png');
INSERT INTO `core_watermark` VALUES ('9', 'wm_alpha', '60');
INSERT INTO `core_watermark` VALUES ('10', 'wm_imgquality', '75');

-- -----------------------------
-- Table structure for `core_web_config`
-- -----------------------------
DROP TABLE IF EXISTS `core_web_config`;
CREATE TABLE `core_web_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `core_web_config`
-- -----------------------------
INSERT INTO `core_web_config` VALUES ('1', 'web_site_title', 'Xiamen Sanan Integrated Circuit Co., Ltd.');
INSERT INTO `core_web_config` VALUES ('2', 'web_site_description', 'Xiamen Sanan Integrated Circuit Co., Ltd.');
INSERT INTO `core_web_config` VALUES ('3', 'web_site_keyword', 'Xiamen Sanan Integrated Circuit Co., Ltd.');
INSERT INTO `core_web_config` VALUES ('4', 'web_site_icp', '陇ICP备15002349号-1');
INSERT INTO `core_web_config` VALUES ('9', 'web_footer_javascript', '');
INSERT INTO `core_web_config` VALUES ('6', 'web_site_copy', '<div class=\"at_on\">Copyright © 2014-2020 | Legal |&nbsp;<a href=\"https://beian.miit.gov.cn\" target=\"_blank\">闽ICP备15009507号-1</a></div>');
INSERT INTO `core_web_config` VALUES ('5', 'web_serviceLine', '86-592-6300505');
INSERT INTO `core_web_config` VALUES ('7', 'web_site_logo', '');
INSERT INTO `core_web_config` VALUES ('8', 'web_head_javascript', '');
INSERT INTO `core_web_config` VALUES ('13', 'web_site_address', '753-799 Min\'an Avenue, Hongtang Town, Tong\'an District, Xiamen City');
INSERT INTO `core_web_config` VALUES ('14', 'web_site_qrcode', '20211020/d5517f0ada075e33af592eb82287dbb2.jpg');
INSERT INTO `core_web_config` VALUES ('15', 'web_site_ico', '');
INSERT INTO `core_web_config` VALUES ('16', 'web_qq', '');
INSERT INTO `core_web_config` VALUES ('17', 'web_contact', '');
INSERT INTO `core_web_config` VALUES ('18', 'web_site_waplogo', '');
INSERT INTO `core_web_config` VALUES ('19', 'web_email', '');
INSERT INTO `core_web_config` VALUES ('20', 'web_site_wapqrcode', '');

-- -----------------------------
-- Table structure for `core_wx_account`
-- -----------------------------
DROP TABLE IF EXISTS `core_wx_account`;
CREATE TABLE `core_wx_account` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `wx_name` varchar(32) DEFAULT NULL COMMENT '公众号名称',
  `appid` varchar(32) DEFAULT NULL,
  `appsecret` varchar(64) DEFAULT NULL,
  `access_token_time` int(11) DEFAULT NULL COMMENT 'token的更新时间',
  `access_token` text,
  `jsapi_ticket_time` int(11) DEFAULT NULL COMMENT 'ticket更新时间',
  `jsapi_ticket` text,
  `token` varchar(32) DEFAULT NULL COMMENT '开发者模式的token',
  `mch_id` varchar(16) DEFAULT NULL COMMENT '微信支付商户号',
  `sub_mch_id` varchar(16) DEFAULT NULL COMMENT '子商户号',
  `pay_key` varchar(32) DEFAULT NULL COMMENT '微信支付密钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `appid` (`appid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='微信公众号';

-- -----------------------------
-- Records of `core_wx_account`
-- -----------------------------
INSERT INTO `core_wx_account` VALUES ('1', 'ces', '121212', '2222', '', '', '', '', '', '2222', '', '2222');

-- -----------------------------
-- Table structure for `core_wx_member`
-- -----------------------------
DROP TABLE IF EXISTS `core_wx_member`;
CREATE TABLE `core_wx_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `openid` varchar(32) NOT NULL,
  `nickname` varchar(128) NOT NULL,
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 未知 1 男 2 女',
  `country` varchar(32) NOT NULL,
  `province` varchar(32) NOT NULL,
  `city` varchar(32) NOT NULL,
  `subscribe_time` int(11) NOT NULL COMMENT '关注的时间',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '最后登录时间',
  `create_ip` varchar(20) NOT NULL,
  `update_ip` varchar(20) NOT NULL,
  `phone` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `headimgurl` varchar(512) NOT NULL COMMENT '头像地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid` (`openid`),
  KEY `appid` (`appid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

